(() => {
  // After the extension is reloaded/updated, old copies in open tabs go dead. Replace them instead of bailing out.
  const alive = () => { try { return !!chrome.runtime.id; } catch { return false; } };
  if (!alive()) return;
  if (window.__jarvisAgent) { if (window.__jarvisAgent.alive()) return; try { window.__jarvisAgent.host.remove(); } catch {} }
  window.__jarvisAgent = { alive };
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;left:0;width:0;height:0';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `<style>
  *{box-sizing:border-box;font-family:system-ui,sans-serif}
  #orb{position:fixed;width:56px;height:56px;border-radius:50%;cursor:grab;touch-action:none;background:radial-gradient(circle,#fff 0 12%,#ffb08f 30%,#ff5a1f 55%,#14181c 58%);box-shadow:0 0 24px #ff5a1f99,0 6px 20px #0008;transition:filter .3s}
  #orb:before,#orb:after{content:"";position:absolute;inset:-6px;border-radius:50%;border:2px dashed #ff5a1f;animation:sp 9s linear infinite}
  #orb:after{inset:-13px;border:2px solid #ff5a1f55;border-top-color:transparent;animation-duration:3s;animation-direction:reverse}
  #orb.busy:before{animation-duration:1.4s}#orb.busy{filter:brightness(1.25)}
  @keyframes sp{to{transform:rotate(360deg)}}
  .ghost{position:fixed;width:30px;height:30px;border-radius:50%;background:#ff5a1f;pointer-events:none;animation:gh .6s forwards}
  @keyframes gh{to{opacity:0;transform:scale(.2)}}
  #panel{position:fixed;width:340px;max-width:92vw;background:#14181c;color:#e7ece9;border-radius:16px;box-shadow:0 20px 60px #000a;display:none;flex-direction:column;overflow:hidden;border:1px solid #2a3138}
  #panel.open{display:flex}
  #hd{display:flex;align-items:center;padding:10px 14px;font-weight:700;border-bottom:1px solid #2a3138}#hd span{flex:1}#hd button{background:none;border:0;color:#9aa6ae;cursor:pointer;font-size:16px}#mic.on{color:#ff5a1f;animation:pl 1.2s infinite}#vo.off{opacity:.35}@keyframes pl{50%{transform:scale(1.3)}}
  #log{max-height:260px;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:1.45}
  .m{padding:8px 11px;border-radius:10px;max-width:92%}.a{background:#1f262c}.u{background:#ff5a1f;align-self:flex-end}.e{background:#3a1f1f;color:#ffb4a8}.s{color:#9aa6ae;font-size:12px}
  #ap{display:none;gap:8px;padding:0 12px 10px}#ap.on{display:flex}#ap button,#go,#st{background:#ff5a1f;color:#fff;border:0;border-radius:999px;padding:7px 14px;cursor:pointer;font-size:13px}#ap #no,#st{background:#38414a}
  #bar{display:flex;gap:8px;padding:10px;border-top:1px solid #2a3138}#in{flex:1;background:#0e1215;border:1px solid #2f383f;border-radius:10px;color:#fff;padding:8px 10px;font-size:13px;outline:0}
  #orb:before,#orb:after{display:none}
  #orb{width:96px;height:96px;background:none;box-shadow:none;filter:drop-shadow(0 10px 12px #0009)}#orb.busy{filter:drop-shadow(0 0 14px #19d3ff) drop-shadow(0 10px 12px #0009)}
  #rig{transform-origin:50px 90px;transform:scaleX(var(--f,1)) rotate(var(--t,0deg));transition:transform .35s}
  .hv{animation:hv 2.2s ease-in-out infinite}@keyframes hv{50%{transform:translateY(-4px)}}
  .gl{animation:gl 2.2s ease-in-out infinite;transform-origin:50px 92px}@keyframes gl{50%{transform:scale(.75);opacity:.25}}
  .core{animation:cr 1.6s ease-in-out infinite}#orb.busy .core{animation-duration:.45s}@keyframes cr{50%{opacity:.35}}
  .ey{animation:bk 4.5s infinite;transform-origin:50px 26px}@keyframes bk{0%,94%,100%{transform:scaleY(1)}97%{transform:scaleY(.1)}}
  .an{animation:cr 1s infinite}.arm{transform-origin:72px 42px}#orb.busy .arm,#orb.listen .arm{animation:wv .6s ease-in-out infinite}@keyframes wv{50%{transform:rotate(-40deg)}}
  .wh{transform-box:fill-box}.wh circle{transform-box:fill-box;transform-origin:center}#orb.moving .wh circle{animation:sp .25s linear infinite}
  #orb.listen:after{display:block;content:"";position:absolute;inset:6px;border-radius:50%;border:2px solid #19d3ff;animation:rp 1.4s infinite;pointer-events:none}@keyframes rp{to{transform:scale(1.7);opacity:0}}
  #panel{background:linear-gradient(160deg,#0b1722ee,#14181cee);backdrop-filter:blur(14px);border:1px solid #19d3ff55;box-shadow:0 0 40px #19d3ff2a,0 20px 60px #000a}
  #hd{font-family:"Courier New",monospace;letter-spacing:.22em;color:#19d3ff}.m.a{border-left:2px solid #19d3ff}#st{background:#38414a}
  #boot{position:fixed;inset:0;display:none;place-items:center;background:radial-gradient(circle,#042033ee,#000000f2);opacity:1;transition:opacity .7s}#boot.on{display:grid}
  #boot:after{content:"";position:absolute;left:0;right:0;height:110px;background:linear-gradient(transparent,#19d3ff40,transparent);animation:sc 1.6s linear infinite}@keyframes sc{from{top:-120px}to{top:100%}}
  .r{position:absolute;border-radius:50%;border:2px solid #19d3ff;box-shadow:0 0 30px #19d3ff77,inset 0 0 30px #19d3ff33}
  .r1{width:300px;height:300px;border-style:dashed;animation:sp 8s linear infinite}.r2{width:220px;height:220px;border-color:#ff5a1f;border-top-color:transparent;border-bottom-color:transparent;animation:sp 2.4s linear infinite reverse}.r3{width:120px;height:120px;background:radial-gradient(circle,#fff,#19d3ff 50%,transparent 72%);animation:cr 1s infinite}
  #bt{position:absolute;top:calc(50% + 190px);font:700 18px "Courier New",monospace;letter-spacing:.3em;color:#19d3ff;text-shadow:0 0 14px #19d3ff;text-align:center;width:100%}
  #hear{padding:0 14px 6px;font-size:12px;color:#19d3ff;font-style:italic;min-height:0}#orb.hear .hv{animation-duration:.5s}#orb.ack{animation:ak .35s}@keyframes ak{50%{transform:scale(1.15)}}
  #bot [fill="#fff"]{fill:#c4161c}#bot [fill="#cfd3d6"]{fill:#e0a93b}#bot [fill="#ff5a1f"]{fill:#ffc247}
  </style><div id="orb" title="JARVIS (Alt+J)"><svg id="bot" viewBox="0 0 100 100" width="96" height="96"><g id="rig"><ellipse class="gl" cx="50" cy="92" rx="30" ry="5" fill="#19d3ff" opacity=".5"/><g class="hv"><path d="M8 74 Q8 80 16 80 L84 80 Q92 80 92 74 L86 76 L14 76 Z" fill="#ff5a1f"/><rect x="14" y="76" width="72" height="3.5" rx="1.7" fill="#14181c"/><g class="wh"><circle cx="28" cy="85" r="4.5" fill="#fff" stroke="#14181c" stroke-width="2"/><circle cx="72" cy="85" r="4.5" fill="#fff" stroke="#14181c" stroke-width="2"/></g><rect x="38" y="62" width="8" height="14" rx="3" fill="#cfd3d6" stroke="#14181c" stroke-width="2"/><rect x="55" y="62" width="8" height="14" rx="3" fill="#cfd3d6" stroke="#14181c" stroke-width="2"/><rect x="24" y="40" width="9" height="22" rx="4.5" fill="#cfd3d6" stroke="#14181c" stroke-width="2" transform="rotate(14 28 42)"/><g class="arm"><rect x="68" y="40" width="9" height="22" rx="4.5" fill="#cfd3d6" stroke="#14181c" stroke-width="2" transform="rotate(-14 72 42)"/></g><rect x="33" y="38" width="34" height="29" rx="10" fill="#fff" stroke="#14181c" stroke-width="2.5"/><circle class="core" cx="50" cy="52" r="6.5" fill="#19d3ff"/><circle cx="50" cy="52" r="10" fill="none" stroke="#ff5a1f" stroke-width="1.5" stroke-dasharray="3 3"/><line x1="50" y1="14" x2="50" y2="8" stroke="#14181c" stroke-width="2.5"/><circle class="an" cx="50" cy="6" r="3.5" fill="#ff5a1f"/><rect x="35" y="14" width="30" height="25" rx="11" fill="#fff" stroke="#14181c" stroke-width="2.5"/><rect x="39" y="21" width="22" height="10" rx="5" fill="#14181c"/><circle class="ey" cx="45.5" cy="26" r="2.4" fill="#19d3ff"/><circle class="ey" cx="54.5" cy="26" r="2.4" fill="#19d3ff"/></g></g></svg></div><div id="boot"><i class="r r1"></i><i class="r r2"></i><i class="r r3"></i><div id="bt"></div></div>
  <div id="panel"><div id="hd"><span>JARVIS</span><button id="mic" title="Listen (hands-free)">🎤</button><button id="vo" title="Voice replies">🔊</button><button id="x">✕</button></div><div id="log"></div>
  <div id="hear"></div><div id="ap"><button id="yes">Approve</button><button id="no">Cancel</button></div>
  <div id="bar"><input id="in" placeholder="Tell JARVIS what to do…"><button id="go">Go</button><button id="st">Stop</button></div></div>`;
  document.documentElement.appendChild(host);
  window.__jarvisAgent.host = host;
  const $ = s => root.querySelector(s), orb = $('#orb'), panel = $('#panel'), logEl = $('#log');
  const bg = m => new Promise(r => { try { chrome.runtime.sendMessage(m, r); } catch { r(null); } });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const store = { get: k => chrome.storage.local.get(k).then(v => v[k]), set: (k, v) => chrome.storage.local.set({ [k]: v }) };
  let pos = { x: 0.92, y: 0.82 }, job = null, tabId = null, running = false, approveResolve = null;

  /* ---- orb: position, drag, fly ---- */
  const px = () => ({ x: Math.min(innerWidth - 70, Math.max(8, pos.x * innerWidth)), y: Math.min(innerHeight - 70, Math.max(8, pos.y * innerHeight)) });
  function place(x, y) { orb.style.left = x + 'px'; orb.style.top = y + 'px'; }
  function home() { const p = px(); place(p.x, p.y); }
  function trail(ms) { const t = setInterval(() => { const r = orb.getBoundingClientRect(), g = document.createElement('div'); g.className = 'ghost'; g.style.left = r.left + 13 + 'px'; g.style.top = r.top + 13 + 'px'; root.appendChild(g); setTimeout(() => g.remove(), 650); }, 45); setTimeout(() => clearInterval(t), ms); }
  async function flyTo(x, y, ms = 900) {
    const r = orb.getBoundingClientRect(), dx = x - r.left, dy = y - r.top;
    trail(ms); orb.style.setProperty('--f', dx < 0 ? -1 : 1); orb.style.setProperty('--t', Math.max(-14, Math.min(14, dx / 25)) + 'deg'); orb.classList.add('moving');
    const a = orb.animate([{ transform: 'translate(0,0) scale(1)' }, { transform: `translate(${dx * .5}px,${dy * .5 - 90}px) scale(1.2)` }, { transform: `translate(${dx}px,${dy}px) scale(1)` }], { duration: ms, easing: 'cubic-bezier(.5,0,.2,1)' });
    await a.finished.catch(() => {}); place(x, y); orb.classList.remove('moving'); orb.style.setProperty('--t', '0deg'); if (panel.classList.contains('open')) fit();
  }
  async function flyIn() { const p = px(); place(innerWidth + 30, -60); await flyTo(p.x, p.y, 1100); }
  function fit() { const o = orb.getBoundingClientRect(), h = panel.offsetHeight || 300; panel.style.left = Math.max(8, Math.min(innerWidth - 348, o.left - 290)) + 'px'; panel.style.top = (o.top > h + 20 ? o.top - h - 12 : o.bottom + 12) + 'px'; }
  let drag = null;
  orb.onpointerdown = e => { drag = { sx: e.clientX, sy: e.clientY, ox: orb.offsetLeft, oy: orb.offsetTop, moved: false }; orb.setPointerCapture(e.pointerId); orb.style.cursor = 'grabbing'; };
  orb.onpointermove = e => { if (!drag) return; const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy; if (Math.abs(dx) + Math.abs(dy) > 5) drag.moved = true; if (drag.moved) { place(drag.ox + dx, drag.oy + dy); if (panel.classList.contains('open')) fit(); } };
  orb.onpointerup = () => { orb.style.cursor = 'grab'; if (!drag) return; if (drag.moved) { pos = { x: orb.offsetLeft / innerWidth, y: orb.offsetTop / innerHeight }; store.set('orbPos', pos); } else toggle(); drag = null; };
  function toggle(on) { panel.classList.toggle('open', on); if (panel.classList.contains('open')) { fit(); $('#in').focus(); } }
  addEventListener('keydown', e => { if (e.altKey && e.key.toLowerCase() === 'j') { e.preventDefault(); toggle(); } });
  $('#x').onclick = () => toggle(false);
  addEventListener('resize', home);

  /* ---- chat log ---- */
  let speakOn = true;
  function say(cls, text) {
    if (cls === 'a' && speakOn && window.speechSynthesis) { try { speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(String(text).slice(0, 200))); } catch {} } const d = document.createElement('div'); d.className = 'm ' + cls; d.textContent = text; logEl.appendChild(d); logEl.scrollTop = logEl.scrollHeight; if (panel.classList.contains('open')) fit(); }
  const approve = text => new Promise(res => { say('s', 'Needs your OK: ' + text); $('#ap').classList.add('on'); toggle(true); approveResolve = ok => { $('#ap').classList.remove('on'); approveResolve = null; res(ok); }; });
  $('#yes').onclick = () => approveResolve && approveResolve(true);
  $('#no').onclick = () => approveResolve && approveResolve(false);

  /* ---- reading the page ---- */
  function snap() {
    document.querySelectorAll('[data-jv]').forEach(x => x.removeAttribute('data-jv'));
    const out = [];
    document.querySelectorAll('a[href],button,input,textarea,select,[role=button],[role=link],[onclick]').forEach(e => {
      if (out.length >= 50 || host.contains(e)) return;
      const r = e.getBoundingClientRect();
      if (r.width < 4 || r.height < 4 || getComputedStyle(e).visibility === 'hidden') return;
      const id = out.length; e.setAttribute('data-jv', id);
      out.push({ id, tag: e.tagName.toLowerCase(), type: e.type || undefined, label: (e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.name || e.title || '').trim().replace(/\s+/g, ' ').slice(0, 80), href: e.href ? String(e.href).slice(0, 90) : undefined, onScreen: r.top < innerHeight && r.bottom > 0 });
    });
    return out;
  }
  const parse = t => { try { return JSON.parse((String(t).match(/\{[\s\S]*\}/) || [''])[0]); } catch { return null; } };
  const SENSITIVE = /(buy|purchase|pay|place order|checkout|delete|remove|confirm|send|submit|book|transfer|subscribe|post|publish)/i;
  const SECRET = /(password|passwd|card|cc-|cvv|cvc|iban|ssn|otp|pin)/i;
  function typeInto(el, text) {
    el.focus();
    const set = Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value'); set && set.set ? set.set.call(el, text) : (el.value = text);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const enter = el => { ['keydown', 'keypress', 'keyup'].forEach(t => el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }))); if (el.form) el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit(); };

  /* ---- agent loop (survives page navigation) ---- */
  const save = () => store.set('job' + tabId, job);
  async function finish(msg) { if (msg) say('a', msg); if (job) { job.status = 'idle'; await save(); } orb.classList.remove('busy'); home && flyTo(px().x, px().y, 800); }
  async function act(a) {
    const el = a.id != null ? document.querySelector(`[data-jv="${a.id}"]`) : null;
    if (a.action === 'done' || a.action === 'ask') { job.awaiting = a.action === 'ask'; await finish(); return 'stop'; }
    if (a.action === 'navigate') {
      if (!/^https?:\/\//i.test(a.url || '')) { job.history.push('bad url'); return 'go'; }
      job.history.push('navigate ' + a.url); await save(); await bg({ type: 'nav', url: a.url }); return 'nav';
    }
    if (a.action === 'scroll') { scrollBy({ top: (a.dir === 'up' ? -1 : 1) * innerHeight * .8, behavior: 'smooth' }); job.history.push('scroll ' + (a.dir || 'down')); await sleep(900); return 'go'; }
    if (!el) { job.history.push('element ' + a.id + ' not found'); return 'go'; }
    const r = el.getBoundingClientRect(), label = (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().slice(0, 40);
    if (SECRET.test([el.type, el.name, el.id, el.autocomplete].join(' '))) { say('e', 'I never fill passwords or payment fields. Please do this step yourself, then tell me to continue.'); job.history.push('blocked: secret field'); await finish(); return 'stop'; }
    el.scrollIntoView({ block: 'center', behavior: 'smooth' }); await sleep(260);
    const r2 = el.getBoundingClientRect(); await flyTo(Math.max(8, r2.left - 20), Math.max(8, r2.top - 40), 450);
    el.style.outline = '3px solid #ff5a1f'; setTimeout(() => (el.style.outline = ''), 1200);
    if (a.action === 'type') { typeInto(el, String(a.text || '')); job.history.push(`typed "${String(a.text || '').slice(0, 30)}" into ${a.id}`); if (a.submit) { await sleep(300); enter(el); } }
    else if (a.action === 'click') {
      if (SENSITIVE.test(label) && !(await approve(`click "${label}" on ${location.hostname}`))) { job.history.push('user declined click ' + label); await finish('Cancelled.'); return 'stop'; }
      el.click(); job.history.push('clicked "' + label + '"');
    } else job.history.push('unknown action');
    await sleep(700); return 'go';
  }
  async function loop() {
    if (running) return; running = true; orb.classList.add('busy');
    try {
      while (job && job.status === 'running') {
        if (job.steps >= 25) { await finish('Step limit reached. Tell me to continue if needed.'); break; }
        const payload = { goal: job.goal, url: location.href, title: document.title, text: document.body.innerText.replace(/\s+/g, ' ').slice(0, 1200), elements: snap(), history: job.history.slice(-8) };
        const res = await bg({ type: 'ask', messages: [{ role: 'user', content: JSON.stringify(payload) }] });
        if (!res || res.error) { say('e', (res && res.error) || 'No response from JARVIS server.'); await finish(); break; }
        const a = parse(res.text); job.steps++;
        if (!a) { job.history.push('unreadable reply'); job.bad = (job.bad || 0) + 1; await save(); if (job.bad >= 2) { say('e', 'The server did not answer in agent mode. Open the JARVIS toolbar popup, set the API address to your site (https://YOUR-SITE.vercel.app/api/chat), press Test, and make sure the latest api/chat.js is deployed.'); await finish(); break; } await sleep(600); continue; }
        if (a.say) say('a', a.say);
        const out = await act(a); await save();
        if (out === 'stop' || out === 'nav') break;
      }
    } finally { running = false; if (!job || job.status !== 'running') orb.classList.remove('busy'); }
  }
  async function start(text) {
    text = text.trim(); if (!text) return;
    if (job && job.awaiting) { job.goal += ' (user replied: ' + text + ')'; job.awaiting = false; job.status = 'running'; }
    else if (job && job.status === 'idle' && job.history.length && /^(continue|go on|resume)\b/i.test(text)) job.status = 'running';
    else job = { goal: text, steps: 0, history: [], status: 'running' };
    job.steps = 0; job.bad = 0;
    await save(); loop();
  }
  $('#go').onclick = () => { const i = $('#in'); const t = i.value; i.value = ''; handle(t); };
  $('#in').onkeydown = e => { if (e.key === 'Enter') $('#go').click(); e.stopPropagation(); };
  $('#in').onkeyup = e => e.stopPropagation();
  $('#st').onclick = async () => { if (job) { job.status = 'idle'; await save(); } approveResolve && approveResolve(false); say('s', 'Stopped.'); orb.classList.remove('busy'); };
  chrome.runtime.onMessage.addListener(m => { if (m.type === 'activated') flyIn(); if (m.type === 'wake') activate(true); });


  /* ---- direct commands: no AI needed, so "click X" just clicks ---- */
  const SITES = { youtube: 'youtube.com', google: 'google.com', gmail: 'mail.google.com', github: 'github.com', facebook: 'facebook.com', instagram: 'instagram.com', twitter: 'x.com', x: 'x.com', whatsapp: 'web.whatsapp.com', amazon: 'amazon.in', netflix: 'netflix.com', linkedin: 'linkedin.com', reddit: 'reddit.com', dribbble: 'dribbble.com', wikipedia: 'wikipedia.org', vercel: 'vercel.com', chatgpt: 'chatgpt.com', maps: 'maps.google.com' };
  const SEARCH = { youtube: 'https://www.youtube.com/results?search_query=', google: 'https://www.google.com/search?q=', amazon: 'https://www.amazon.in/s?k=', github: 'https://github.com/search?q=', wikipedia: 'https://en.wikipedia.org/w/index.php?search=' };
  const toUrl = s => { s = s.trim().replace(/\s+dot\s+/gi, '.').replace(/\s+/g, ''); if (/^https?:\/\//i.test(s)) return s; const k = s.toLowerCase().replace(/\.com$/, ''); if (SITES[k]) return 'https://' + SITES[k]; return /\.[a-z]{2,}/i.test(s) ? 'https://' + s : 'https://www.' + s + '.com'; };
  const siteKey = s => { const k = s.toLowerCase().replace(/\s+/g, '').replace(/\.com$/, ''); return SEARCH[k] ? k : null; };
  function parseCmd(text) {
    const s = text.replace(/^(hey |ok |okay )?jarvis[, ]*/i, '').replace(/^(please|can you|could you|kindly)\s+/i, '').replace(/[.!?]+$/, '').trim(); let m;
    if (!s || /^(wake up|wake|activate|initialize|initialise|boot up|hello|hi|hey|are you there|you there)(\s+jarvis)?$/i.test(s)) return { t: 'wake' };
    if (/^(stop|cancel|abort|never mind)$/i.test(s)) return { t: 'stop' };
    if (/^(press\s+)?(enter|return)$/i.test(s)) return { t: 'enter' };
    if (m = s.match(/^(?:go to|open|visit|navigate to|take me to)\s+(.+?)\s+and\s+(?:search|find|look up)\s+(?:for\s+)?(.+)$/i)) { const k = siteKey(m[1]); return k ? { t: 'nav', url: SEARCH[k] + encodeURIComponent(m[2]) } : { t: 'nav', url: SEARCH.google + encodeURIComponent('site:' + toUrl(m[1]).replace(/^https?:\/\/(www\.)?/, '') + ' ' + m[2]) }; }
    if (m = s.match(/^(?:search|find|look up|google)\s+(?:for\s+)?(.+?)\s+(?:on|in)\s+(youtube|google|amazon|github|wikipedia)$/i)) return { t: 'nav', url: SEARCH[m[2].toLowerCase()] + encodeURIComponent(m[1]) };
    if (m = s.match(/^(?:search|look up|google)\s+(?:for\s+)?(.+)$/i)) return { t: 'nav', url: SEARCH.google + encodeURIComponent(m[1]) };
    if (/^(?:open|new)\s+(?:a\s+)?new\s+tab$|^new tab$/i.test(s)) return { t: 'tabs', op: 'new' };
    if (m = s.match(/^open\s+(?:a\s+)?new\s+tab\s+(?:with|and (?:go to|open))\s+(.+)$/i)) return { t: 'tabs', op: 'new', url: toUrl(m[1]) };
    if (m = s.match(/^(?:go to|open|visit|navigate to|take me to)\s+(.+)$/i)) return { t: 'nav', url: toUrl(m[1]) };
    if (/^(?:next|right)\s+tab$|^(?:switch|go)\s+to\s+(?:the\s+)?next\s+tab$/i.test(s)) return { t: 'tabs', op: 'next' };
    if (/^(?:previous|prev|last|left)\s+tab$|^(?:switch|go)\s+to\s+(?:the\s+)?(?:previous|last)\s+tab$/i.test(s)) return { t: 'tabs', op: 'prev' };
    if (m = s.match(/^(?:switch|go|jump|move)\s+to\s+(?:the\s+)?(?:tab\s+(?:number\s+)?)?(.+?)(?:\s+tab)?$/i)) return { t: 'tabs', op: 'switch', q: m[1] };
    if (/^close\s+(?:this\s+)?tab$/i.test(s)) return { t: 'tabs', op: 'close' };
    if (/^(?:list|show)\s+(?:my\s+)?tabs$/i.test(s)) return { t: 'tabs', op: 'list' };
    if (/^(?:go\s+)?back$/i.test(s)) return { t: 'hist', op: 'back' };
    if (/^(?:go\s+)?forward$/i.test(s)) return { t: 'hist', op: 'forward' };
    if (/^(?:reload|refresh)(?:\s+(?:the\s+)?page)?$/i.test(s)) return { t: 'hist', op: 'reload' };
    if (m = s.match(/^(?:scroll|go|move)\s*(down|up|to the top|to the bottom|to top|to bottom|top|bottom)?$/i)) { const d = (m[1] || 'down').toLowerCase(); return { t: 'scroll', d: /top/.test(d) ? 'top' : /bottom/.test(d) ? 'bottom' : d }; }
    if (m = s.match(/^(?:click|tap|press|hit|select|choose|open)(?:\s+on)?\s+(.+)$/i)) return { t: 'click', q: m[1] };
    if (/^(?:type|write|enter|fill(?: in)?)\s+/i.test(s)) { const sub = /\s+and\s+(?:press\s+)?(?:enter|search|submit)$/i.test(s), body = s.replace(/\s+and\s+(?:press\s+)?(?:enter|search|submit)$/i, ''); if (m = body.match(/^(?:type|write|enter|fill(?: in)?)\s+(.+?)(?:\s+(?:in|into|on)\s+(?:the\s+)?(.+?))?$/i)) return { t: 'type', text: m[1], q: m[2], submit: sub }; }
    return null;
  }
  async function touch(el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); await sleep(240); const r = el.getBoundingClientRect(); await flyTo(Math.max(8, r.left - 20), Math.max(8, r.top - 40), 450); el.style.outline = '3px solid #ff5a1f'; setTimeout(() => (el.style.outline = ''), 1200); }
  function pick(q, ok) {
    const w = q.toLowerCase().replace(/^(the|a|an)\s+/, '').replace(/\s+(button|link|tab|icon|field|box|option)$/, '').trim(); let best = null, bs = 0;
    for (const e of snap()) { if (ok && !ok(e)) continue; const l = e.label.toLowerCase(); if (!l) continue; let sc = l === w ? 4 : l.startsWith(w) ? 3 : l.includes(w) ? 2 : w.split(' ').every(t => l.includes(t)) ? 1.5 : 0; if (sc && e.onScreen) sc += .5; if (sc > bs) { bs = sc; best = e; } }
    return best && document.querySelector(`[data-jv="${best.id}"]`);
  }
  async function go(u) { say('a', 'Opening ' + u.replace(/^https?:\/\/(www\.)?/, '').slice(0, 60)); await flyTo(innerWidth + 40, -60, 500); await bg({ type: 'nav', url: u }); }
  async function local(text) {
    const c = parseCmd(text); if (!c) return false;
    if (c.t === 'wake') { activate(false); return true; }
    if (c.t === 'stop') { $('#st').click(); return true; }
    if (job && job.status === 'running') { job.status = 'idle'; await save(); }
    if (c.t === 'nav') { await go(c.url); return true; }
    if (c.t === 'tabs') { if (c.op !== 'new' && c.op !== 'list' && c.op !== 'close') await flyTo(innerWidth + 40, -60, 450); const r = await bg({ type: 'tabs', op: c.op, q: c.q, url: c.url }); if (r && r.say) say('a', r.say); return true; }
    if (c.t === 'hist') { say('a', c.op === 'back' ? 'Going back.' : c.op === 'forward' ? 'Going forward.' : 'Reloading.'); await sleep(300); c.op === 'back' ? history.back() : c.op === 'forward' ? history.forward() : location.reload(); return true; }
    if (c.t === 'scroll') { c.d === 'top' ? scrollTo({ top: 0, behavior: 'smooth' }) : c.d === 'bottom' ? scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' }) : scrollBy({ top: (c.d === 'up' ? -1 : 1) * innerHeight * .8, behavior: 'smooth' }); say('a', 'Scrolling ' + c.d + '.'); return true; }
    if (c.t === 'enter') { const el = document.activeElement && document.activeElement !== document.body ? document.activeElement : null; if (!el) { say('e', 'Nothing is focused. Tell me where to type first.'); return true; } enter(el); say('a', 'Enter pressed.'); return true; }
    if (c.t === 'click') {
      const el = pick(c.q); if (!el) { const sw = c.q; say('e', `I can't see "${sw}" on this page. Say "scroll down" and try again, or describe it differently.`); return true; }
      await touch(el); const label = (el.innerText || el.value || el.getAttribute('aria-label') || c.q).trim().slice(0, 40); el.click(); say('a', 'Clicked ' + label + '.'); return true;
    }
    if (c.t === 'type') {
      const field = e => /^(input|textarea)$/.test(e.tag) && !/^(hidden|checkbox|radio|submit|button|file)$/.test(e.type || '');
      let el = c.q ? pick(c.q, field) : null;
      if (!el && !c.q) { const a = document.activeElement; el = a && /^(INPUT|TEXTAREA)$/.test(a.tagName) ? a : (() => { const f = snap().find(e => field(e) && e.onScreen); return f && document.querySelector(`[data-jv="${f.id}"]`); })(); }
      if (!el) { say('e', 'I could not find a text box to type in.'); return true; }
      if (SECRET.test([el.type, el.name, el.id, el.autocomplete].join(' '))) { say('e', 'I never fill passwords or payment fields. Please type that yourself.'); return true; }
      await touch(el); typeInto(el, c.text); if (c.submit) { await sleep(300); enter(el); } say('a', 'Typed it' + (c.submit ? ' and pressed enter.' : '.')); return true;
    }
    return false;
  }
  function ack() { orb.classList.add('ack'); setTimeout(() => orb.classList.remove('ack'), 380); }
  async function handle(text) { text = (text || '').trim(); if (!text) return; say('u', text); if (!(await local(text))) await start(text); }

  /* ---- voice: hands-free listening that follows you across tabs ---- */
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition; let rec = null, listening = false;
  function mk() {
    if (!listening || document.visibilityState !== 'visible') return;
    rec = new SR(); rec.lang = navigator.language || 'en-US'; rec.continuous = true; rec.interimResults = true;
    rec.onspeechstart = () => orb.classList.add('hear'); rec.onspeechend = () => orb.classList.remove('hear');
    rec.onresult = e => { if (window.speechSynthesis && speechSynthesis.speaking) return; const r = e.results[e.results.length - 1], t = r[0].transcript.trim(); $('#hear').textContent = t && !r.isFinal ? '🎤 ' + t : ''; if (r.isFinal && t) { ack(); handle(t); } };
    rec.onerror = e => { if (e.error === 'not-allowed' || e.error === 'service-not-allowed') { listening = false; $('#mic').classList.remove('on'); store.set('listen', false); say('e', 'Microphone is blocked on this site. Click the lock icon in the address bar, allow Microphone, then press 🎤 again.'); } };
    rec.onend = () => { if (listening && document.visibilityState === 'visible') setTimeout(mk, 300); };
    try { rec.start(); } catch {}
  }
  function listen(on) { orb.classList.toggle('listen', on); if (on && !SR) return say('e', 'Voice input is not supported in this browser.'); listening = on; $('#mic').classList.toggle('on', on); store.set('listen', on); if (on) mk(); else { try { rec && rec.abort(); } catch {} } }
  $('#mic').onclick = () => listen(!listening);
  $('#vo').onclick = () => { speakOn = !speakOn; $('#vo').classList.toggle('off', !speakOn); if (!speakOn) speechSynthesis.cancel(); };
  document.addEventListener('visibilitychange', async () => { if (document.visibilityState === 'hidden') { try { rec && rec.abort(); } catch {} } else if (SR && (await store.get('listen'))) { listening = true; $('#mic').classList.add('on'); mk(); } });


  /* ---- Tony Stark style activation ---- */
  async function activate(long = true) {
    const b = $('#boot'), bt = $('#bt'); b.style.opacity = 1; b.classList.add('on'); orb.style.visibility = 'hidden';
    const lines = long ? ['INITIALIZING J.A.R.V.I.S.', 'LOADING NEURAL CORE', 'ALL SYSTEMS ONLINE', 'GOOD DAY, SIR.'] : ['J.A.R.V.I.S. ONLINE'];
    for (const l of lines) { bt.textContent = ''; for (const ch of l) { bt.textContent += ch; await sleep(28); } await sleep(long ? 420 : 500); }
    if (speakOn && window.speechSynthesis) { try { speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance('Good day, sir. JARVIS online.')); } catch {} }
    b.style.opacity = 0; await sleep(700); b.classList.remove('on'); orb.style.visibility = ''; await flyIn();
  }

  /* ---- boot ---- */
  (async () => {
    pos = (await store.get('orbPos')) || pos; home();
    if (!(await store.get('booted')) && window === top) { await store.set('booted', true); activate(true); } else flyIn();
    if (SR && (await store.get('listen')) && document.visibilityState === 'visible') { listening = true; $('#mic').classList.add('on'); mk(); }
    tabId = await bg({ type: 'tabId' }); job = tabId != null ? await store.get('job' + tabId) : null;
    if (job && job.status === 'running') { toggle(true); say('s', 'Continuing: ' + job.goal); await sleep(1200); loop(); }
    else say('s', 'JARVIS online. Try: "open youtube and search for lo-fi", "click Sign in", "scroll down", "next tab". Press 🎤 to talk.');
  })();
})();
