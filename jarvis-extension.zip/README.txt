JARVIS Browser Agent (Chrome / Edge / Brave)

Install / update:
1. Unzip this folder (replace the old one).
2. chrome://extensions -> Developer mode -> "Load unpacked" (or press the reload arrow if already loaded).
3. Click the JARVIS toolbar icon, put your site's API address (https://YOUR-SITE.vercel.app/api/chat), press Save, then Test. It must say "Agent mode works."
   (If not: deploy the latest api/chat.js from jarvis-site-v3.zip.)

Use: click the orb or press Alt+J. Type or press the mic and talk.
Direct commands (instant, no AI): "click Sign in", "scroll down/up/to top", "type hello in the search box and press enter",
"go to youtube.com", "open youtube and search for lo-fi music", "search cats on youtube", "back", "reload",
"next tab", "previous tab", "switch to github tab", "new tab", "close this tab", "list tabs", "stop".
Anything else goes to the AI, which plans and does the steps itself.

Safety: never fills passwords or payment fields; asks before AI-chosen buy/send/delete clicks; stops at login pages for you to sign in.
Mic: the browser asks for microphone permission once per site; allow it. Hands-free listening follows you to the active tab.
If an already-open tab has no orb after updating, the toolbar popup "Wake JARVIS" button injects it. Also check chrome://extensions -> Details -> Site access = On all sites.
Pages Chrome blocks (chrome://, Web Store, PDF viewer) cannot show the orb.
