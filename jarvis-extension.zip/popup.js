const u = document.getElementById('u'), m = document.getElementById('m');
chrome.storage.local.get('apiUrl').then(v => { u.value = v.apiUrl || ''; });
document.getElementById('s').onclick = () => chrome.storage.local.set({ apiUrl: u.value.trim() }).then(() => { m.textContent = 'Saved.'; });
document.getElementById('t').onclick = async () => {
  m.textContent = 'Testing...';
  const url = u.value.trim() || 'https://jarvisv02.vercel.app/api/chat';
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: 'agent', messages: [{ role: 'user', content: JSON.stringify({ goal: 'say hello', url: 'about:blank', elements: [], history: [] }) }] }) });
    const t = await r.text();
    m.textContent = /\{[\s\S]*"action"/.test(t) ? 'Agent mode works.' : r.ok ? 'Server answered but is NOT in agent mode. Deploy the latest api/chat.js.' : 'Error ' + r.status + ': ' + t.slice(0, 120);
  } catch (e) { m.textContent = 'Cannot reach server: ' + e.message; }
};
document.getElementById('w').onclick = async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!t || !/^https?:/.test(t.url || '')) { m.textContent = 'Open a normal website tab first (Chrome blocks chrome:// pages and the Web Store).'; return; }
  const wake = () => chrome.tabs.sendMessage(t.id, { type: 'wake' });
  try { await wake(); window.close(); }
  catch { try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }); setTimeout(() => wake().then(() => window.close()).catch(() => { m.textContent = 'Could not reach this page. Refresh it once and try again.'; }), 700); } catch (e) { m.textContent = 'Blocked on this page: ' + e.message; } }
};
