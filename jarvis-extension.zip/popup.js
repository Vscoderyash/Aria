const u = document.getElementById('u'), m = document.getElementById('m');
chrome.storage.local.get('apiUrl').then(v => { u.value = v.apiUrl || ''; });
document.getElementById('s').onclick = () => chrome.storage.local.set({ apiUrl: u.value.trim() }).then(() => { m.textContent = 'Saved.'; });
document.getElementById('t').onclick = async () => {
  m.textContent = 'Testing...';
  const url = u.value.trim() || 'https://jarvisv02.vercel.app/api/chat';
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: 'agent', messages: [{ role: 'user', content: JSON.stringify({ goal: 'say hello', url: 'about:blank', elements: [], history: [] }) }] }) });
    const t = await r.text();
    m.textContent = /\{[\s\S]*"action"/.test(t) ? 'Agent mode works.' : r.ok ? 'Server answered but is NOT in agent mode. Deploy the latest api/chat.js.' : 'Error ' + r.status + ': ' + t.slice(0, 120);
  } catch (e) { m.textContent = 'Cannot reach server: ' + e.message; }
};
document.getElementById('w').onclick = async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!t || !/^https?:/.test(t.url || '')) { m.textContent = 'Open a normal website tab first (Chrome blocks chrome:// pages and the Web Store).'; return; }
  const wake = () => chrome.tabs.sendMessage(t.id, { type: 'wake' });
  try { await wake(); window.close(); }
  catch { try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }); setTimeout(() => wake().then(() => window.close()).catch(() => { m.textContent = 'Could not reach this page. Refresh it once and try again.'; }), 700); } catch (e) { m.textContent = 'Blocked on this page: ' + e.message; } }
};
const lg = document.getElementById('l'); chrome.storage.local.get('lang').then(v => { lg.value = v.lang || ''; }); lg.onchange = () => chrome.storage.local.set({ lang: lg.value }).then(() => { m.textContent = 'Voice language saved. Refresh your tabs.'; });
const vs = document.getElementById('v'), sz = document.getElementById('z');
function fillVoices() { vs.textContent = ''; const auto = document.createElement('option'); auto.value = ''; auto.textContent = 'Auto (best male voice)'; vs.appendChild(auto); for (const v of speechSynthesis.getVoices().filter(x => /^en/i.test(x.lang))) { const o = document.createElement('option'); o.value = v.name; o.textContent = v.name; vs.appendChild(o); } chrome.storage.local.get('voiceName').then(x => { vs.value = x.voiceName || ''; }); }
speechSynthesis.onvoiceschanged = fillVoices; fillVoices();
vs.onchange = () => chrome.storage.local.set({ voiceName: vs.value });
chrome.storage.local.get('size').then(x => { sz.value = x.size || 'auto'; }); sz.onchange = () => chrome.storage.local.set({ size: sz.value });
chrome.storage.local.get('companion').then(x => { document.getElementById('c').textContent = x.companion ? 'Desktop JARVIS: connected ✓' : 'Desktop JARVIS: not running'; });
const TK = ['skills', 'facts', 'aliases', 'exp', 'lessons'];
async function trainInfo() { const d = await chrome.storage.local.get(TK); document.getElementById('tr').textContent = `Learned: ${Object.keys(d.skills || {}).length} shortcuts, ${(d.facts || []).length} facts, ${Object.keys(d.aliases || {}).length} voice fixes, ${(d.exp || []).length} experiences, ${(d.lessons || []).length} lessons`; }
trainInfo(); chrome.storage.onChanged.addListener(trainInfo);
const brn = document.getElementById('br'); chrome.storage.local.get('brain').then(x => { brn.value = x.brain || 'fast'; }); brn.onchange = () => chrome.storage.local.set({ brain: brn.value });
document.getElementById('ex').onclick = async () => { const d = await chrome.storage.local.get(TK), a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' })); a.download = 'jarvis-training.json'; a.click(); };
document.getElementById('im').onclick = () => document.getElementById('fi').click();
document.getElementById('fi').onchange = async e => { try { const j = JSON.parse(await e.target.files[0].text()), o = {}; for (const k of TK) if (j[k]) o[k] = j[k]; await chrome.storage.local.set(o); m.textContent = 'Training imported.'; } catch { m.textContent = 'That file is not a JARVIS training file.'; } };
document.getElementById('rs').onclick = async () => { if (confirm('Erase everything JARVIS has learned?')) { await chrome.storage.local.remove(TK); m.textContent = 'Training erased.'; } };
