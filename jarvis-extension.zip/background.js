const DEFAULT_API = 'https://jarvisv02.vercel.app/api/chat';
async function ask(messages) {
  const { apiUrl } = await chrome.storage.local.get('apiUrl');
  try {
    const r = await fetch(apiUrl || DEFAULT_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: 'agent', messages }) });
    const t = await r.text();
    if (!r.ok) { let e = t; try { e = JSON.parse(t).error; } catch {} return { error: e }; }
    return { text: t };
  } catch (e) { return { error: e.message }; }
}
chrome.runtime.onMessage.addListener((m, s, send) => {
  if (m.type === 'tabId') { send(s.tab && s.tab.id); return; }
  if (m.type === 'nav' && s.tab && /^https?:\/\//i.test(m.url)) { chrome.tabs.update(s.tab.id, { url: m.url }); send(true); return; }
  if (m.type === 'tabs') { tabsOp(m, s).then(send); return true; }
  if (m.type === 'ask') { ask(m.messages).then(send); return true; }
});
// The orb "flies in" whenever you switch to a tab.
const inject = id => chrome.scripting.executeScript({ target: { tabId: id }, files: ['content.js'] }).catch(() => {});
chrome.tabs.onActivated.addListener(({ tabId }) => chrome.tabs.sendMessage(tabId, { type: 'activated' }).catch(() => inject(tabId)));
chrome.runtime.onInstalled.addListener(async () => { for (const t of await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] })) inject(t.id); });
async function tabsOp(m, s) {
  const all = await chrome.tabs.query({ currentWindow: true }), cur = all.findIndex(t => t.id === s.tab.id);
  if (m.op === 'next' || m.op === 'prev') { const t = all[(cur + (m.op === 'next' ? 1 : all.length - 1)) % all.length]; await chrome.tabs.update(t.id, { active: true }); return { say: 'Switched to ' + (t.title || t.url) }; }
  if (m.op === 'switch') { const q = String(m.q || '').toLowerCase(), i = /^\d+$/.test(q) ? Number(q) - 1 : -1; const t = i >= 0 ? all[i] : all.find(x => ((x.title || '') + ' ' + (x.url || '')).toLowerCase().includes(q)); if (!t) return { say: 'No tab matches "' + m.q + '".' }; await chrome.tabs.update(t.id, { active: true }); return { say: 'Switched to ' + t.title }; }
  if (m.op === 'new') { await chrome.tabs.create({ url: m.url && /^https?:\/\//i.test(m.url) ? m.url : undefined }); return { say: 'Opened a new tab.' }; }
  if (m.op === 'close') { chrome.tabs.remove(s.tab.id); return { say: 'Closing this tab.' }; }
  if (m.op === 'list') return { say: all.map((t, i) => (i + 1) + '. ' + t.title).join('\n') };
  return { say: 'Unknown tab command.' };
}
